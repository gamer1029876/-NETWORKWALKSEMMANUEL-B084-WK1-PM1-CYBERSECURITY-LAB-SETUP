<h1 align="center">🔐 Cybersecurity Lab Environment Setup</h1>

<p align="center"><b>Building an isolated virtual lab for ethical hacking and penetration testing practice</b></p>

<p align="center">
<img src="https://img.shields.io/badge/Skill-Cybersecurity-red" alt="Cybersecurity">
<img src="https://img.shields.io/badge/Hypervisor-VirtualBox-blue" alt="VirtualBox">
<img src="https://img.shields.io/badge/OS-Kali%20Linux-black" alt="Kali Linux">
<img src="https://img.shields.io/badge/Network-10.0.0.0%2F24-teal" alt="Network">
<img src="https://img.shields.io/badge/Skill-Virtualization-red" alt="Virtualization">
<img src="https://img.shields.io/badge/Topic-Ethical%20Hacking-orange" alt="Ethical Hacking">
<img src="https://img.shields.io/badge/Program-NetworkWalks-darkred" alt="NetworkWalks">
</p>

---

## 📌 Project Overview

This project documents how I built a virtual cybersecurity testing lab using **VirtualBox** and **Kali Linux** as part of the Networkwalks Cybersecurity Internship (Week 1, Project Module 1).

The purpose of the lab is to provide a controlled, isolated environment where security tools and techniques can be practiced safely and repeatably. The lab runs on a private NAT Network so that more machines can be added later as authorized targets.

**Intern:** YOUR NAME  |  **Batch:** YOUR BATCH  |  **Task:** WK1-PM1  |  **Date:** DATE  |  **Instructor:** Waqas Karim CCIE

> **Lab safety:** Everything in this project was done inside my own isolated virtual lab on a device I own. No external systems were tested.

## Overview

### Requirements Checklist

- [x] VirtualBox (latest recommended version) as the base
- [x] Kali Linux set up as the attacker machine
- [x] Network subnet `10.0.0.0/24` using a VirtualBox NAT Network
- [x] Clipboard and drag & drop enabled (Bidirectional)
- [x] Shared folder: host `Downloads` folder shared with the VM
- [x] Kali Linux static IP: `10.0.0.2/24`
- [x] Full internet access from Kali Linux
- [x] Snapshot of the working VM

### Lab Architecture

| Component | Detail |
|---|---|
| Host OS | YOUR HOST OS (e.g. Windows 11) |
| Hypervisor | VirtualBox VERSION |
| Guest OS | Kali Linux VERSION (pre-built VirtualBox image) |
| Network | NAT Network `NatNetwork`, `10.0.0.0/24`, DHCP enabled |
| Kali IP | `10.0.0.2/24` |
| Gateway | `10.0.0.1` |
| DNS | `8.8.8.8` |

---

## Step 1: Install 7-Zip

Downloaded and installed 7-Zip from <https://7-zip.org/download.html>. It is needed to extract the compressed Kali image.

![Step 1: 7-Zip download page](screenshots/01-7zip.png)

## Step 2: Install VirtualBox

Downloaded the latest version from <https://virtualbox.org/wiki/Downloads> and installed it with default options.

![Step 2a: VirtualBox download page](screenshots/02-virtualbox-website.png)
![Step 2b: VirtualBox installed (Help > About shows the version)](screenshots/02b-virtualbox-installed.png)

## Step 3: Create the NAT Network

In VirtualBox: **File → Tools → Network → NAT Networks → Create**, then set:

- Name: `NatNetwork`
- IPv4 Prefix: `10.0.0.0/24`
- Enable DHCP: ticked
- Enable IPv6: unticked

![Step 3: NAT Network settings](screenshots/03-nat-network.png)

## Step 4: Download and Import Kali Linux

Downloaded the pre-built **VirtualBox** image from <https://kali.org/get-kali>, extracted it with 7-Zip, and opened the `.vbox` file to add it to VirtualBox.

![Step 4a: Kali download page, Virtual Machines option](screenshots/04a-kali-download.png)
![Step 4b: Kali VM added to VirtualBox](screenshots/04b-kali-imported.png)

## Step 5: Configure VM Settings

With the VM powered off, open **Settings** for the Kali VM.

### 5.1 Network adapter

Adapter 1 is attached to **NAT Network**, name `NatNetwork`. Under Advanced: adapter type Intel PRO/1000 MT Desktop (82540EM), Promiscuous Mode set to *Allow All*, and Virtual Cable Connected ticked.

![Step 5.1: Network adapter](screenshots/05-1-network-adapter.png)

### 5.2 Clipboard and drag & drop

**General → Advanced:** Shared Clipboard and Drag'n'Drop both set to **Bidirectional**.

![Step 5.2: Clipboard and drag and drop](screenshots/05-2-clipboard-dragdrop.png)

### 5.3 Shared folder

**Shared Folders:** added the host `Downloads` folder with Auto-mount and Make Permanent enabled and access set to Full.

![Step 5.3: Shared folder](screenshots/05-3-shared-folder.png)

Inside Kali the folder is available at `/media/sf_Downloads`. If there is a permission error, add the user to the `vboxsf` group and reboot:

```bash
sudo usermod -aG vboxsf kali
```

![Step 5.3b: Shared folder visible inside Kali](screenshots/05-3b-shared-folder-in-kali.png)

### 5.4 System settings

Base memory set to 4096 MB, and hardware virtualization (Nested Paging) enabled under Acceleration. The VM disk is about 130 GB.

![Step 5.4a: Memory and motherboard settings](screenshots/05-4a-system-memory.png)
![Step 5.4b: Acceleration settings](screenshots/05-4b-acceleration.png)

## Step 6: Set the Static IP Address in Kali

Configured **Wired connection 1** with IPv4 method *Manual*:

| Field | Value |
|---|---|
| Address | `10.0.0.2` |
| Netmask | `24` |
| Gateway | `10.0.0.1` |
| DNS | `8.8.8.8` |

![Step 6: IPv4 settings in Kali](screenshots/06-ip-settings.png)

Equivalent terminal commands:

```bash
sudo nmcli connection modify "Wired connection 1" ipv4.method manual ipv4.addresses 10.0.0.2/24 ipv4.gateway 10.0.0.1 ipv4.dns 8.8.8.8 ipv4.dad-timeout 0
sudo nmcli connection down "Wired connection 1"
sudo nmcli connection up "Wired connection 1"
```

## Step 7: Verify Connectivity

```bash
ip a                 # confirm 10.0.0.2/24
ping -c 4 10.0.0.1   # gateway
ping -c 4 8.8.8.8    # internet by IP
ping -c 4 google.com # internet + DNS
```

![Step 7a: ip a output showing 10.0.0.2/24](screenshots/07a-ip-a.png)
![Step 7b: Ping results](screenshots/07b-ping-tests.png)

## Step 8: Take a Snapshot

**Machine → Take Snapshot**, named `Fresh Kali - 10.0.0.2 working`, so I can restore a clean working state at any time.

![Step 8: Snapshot taken](screenshots/08-snapshot.png)

---

## Troubleshooting

**No internet in Kali (common with VirtualBox 7 and newer Kali releases):**

1. Confirm the NAT Network was created correctly.
2. Confirm all network settings match the table above.
3. Make sure no other VM on the same NAT Network is using `10.0.0.2`.
4. Run the three `nmcli` commands from Step 6 and restart Kali.
5. Try `10.0.0.1` as the DNS server instead of `8.8.8.8`.
6. Restart the VM and the host machine.

## Issues Faced

The setup went smoothly and I did not run into any major problems. To help others, these are the common issues to watch for and how to fix them:

| Issue | Fix |
|---|---|
| Kali has no internet after setting a static IP | Run the three `nmcli` commands from Step 6 (including `ipv4.dad-timeout 0`), then restart Kali. Also try `10.0.0.1` as DNS. |
| Another VM is using the same IP | Make sure no other VM on the NAT Network uses `10.0.0.2`. |
| Adapter shows plain *NAT* instead of *NAT Network* | In VM Settings → Network, set Attached to **NAT Network** and choose `NatNetwork`. |
| NAT Network list still shows the default prefix | After typing `10.0.0.0/24`, click **Apply** and check the list updated. |
| Shared folder permission denied in Kali | `sudo usermod -aG vboxsf kali`, then reboot. |

## Key Learnings

- How NAT Networks isolate lab machines while still allowing internet access
- Assigning a static IP with NetworkManager (`nmcli`)
- Using shared folders and clipboard integration to move files between host and VM
- Using snapshots as restore points for safe testing

## Next Steps (Phase 2)

Add Windows 11/10/7 and Android VMs on the same NAT Network (`10.0.0.0/24`) and ping-test between all machines.

---

*This lab is for educational and ethical cybersecurity practice only, in an isolated environment I own. Hacking is only legal on systems you own or have written permission to test.*
